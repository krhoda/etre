module Strand(Strand, complementStrand, stringToStrand) where

import Nucleotide (charToNucleotide, Nucleotide, complement)

type Strand = [Nucleotide]

complementStrand :: Strand -> Strand
complementStrand x = reverse $ [complement y | y <- x]

-- TODO: Use Text.
stringToStrand :: String -> Maybe Strand
stringToStrand x = makeStrandFromString x []

makeStrandFromString :: String -> Strand -> Maybe Strand
makeStrandFromString []       y = Just (reverse y)
makeStrandFromString (x : xs) y = case charToNucleotide x of
  Just z  -> makeStrandFromString xs (z : y)
  Nothing -> Nothing
