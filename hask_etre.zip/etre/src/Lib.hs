module Lib where

someFunc :: IO ()
someFunc = putStrLn "someFunc"
