module Nucleotide where

import           Data.Char (toUpper)

data Nucleotide = A | T | G | C deriving (Show,Eq)

complement :: Nucleotide -> Nucleotide
complement A = T
complement T = A
complement G = C
complement C = G

charToNucleotide :: Char -> Maybe Nucleotide
charToNucleotide x | [toUpper x] == "A" = Just A
                   | [toUpper x] == "T" = Just T
                   | [toUpper x] == "C" = Just C
                   | [toUpper x] == "G" = Just G
                   | otherwise          = Nothing
