module DoubleHelix where

import Nucleotide (Nucleotide(G, C), complement)
import Strand (Strand, complementStrand)

type DoubleHelix = [(Nucleotide, Nucleotide)]

fromStrand :: Strand -> DoubleHelix
fromStrand x = [(y, complement y) | y <- x]

getStrand :: DoubleHelix -> Strand
getStrand x = [fst y | y <- x]

getStrands :: DoubleHelix -> (Strand, Strand)
getStrands x = let y = getStrand x in (y, complementStrand y)

flipDoubleHelix :: DoubleHelix -> DoubleHelix
flipDoubleHelix x = reverse $ [(snd y, fst y) | y <- x]

-- TODO: Use a real fraction or something.
gcContent :: DoubleHelix -> (Int, Int)
gcContent x = (length [a | a <- x, gcCount a], length x)

-- TODO: Move into nucleotide, ammend above to use `fst`
gcCount :: (Nucleotide, Nucleotide) -> Bool
gcCount (G, _) =  True
gcCount (C, _) =  True
gcCount _ = False

